import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
import webbrowser
import folium
import difflib

class Database:
    def __init__(self, db_name="mosques.db"):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS mosque (
                id INTEGER PRIMARY KEY,
                name TEXT,
                type TEXT,
                address TEXT,
                coordinates TEXT,
                imam_name TEXT
            )
        ''')
        self.conn.commit()

    def insert(self, id, name, type_, address, coordinates, imam_name):
        self.cursor.execute("INSERT INTO mosque VALUES (?, ?, ?, ?, ?, ?)",
                            (id, name, type_, address, coordinates, imam_name))
        self.conn.commit()

    def display_all(self):
        self.cursor.execute("SELECT * FROM mosque")
        return self.cursor.fetchall()

    def search(self, name):
        self.cursor.execute("SELECT * FROM mosque WHERE name LIKE ?", ('%' + name + '%',))
        return self.cursor.fetchall()

    def delete(self, id):
        self.cursor.execute("DELETE FROM mosque WHERE id = ?", (id,))
        self.conn.commit()

    def update_imam(self, id, new_imam):
        self.cursor.execute("UPDATE mosque SET imam_name = ? WHERE id = ?", (new_imam, id))
        self.conn.commit()

    def get_all_names(self):
        self.cursor.execute("SELECT name FROM mosque")
        return [row[0] for row in self.cursor.fetchall()]

    def get_by_name(self, name):
        self.cursor.execute("SELECT * FROM mosque WHERE name = ?", (name,))
        return self.cursor.fetchone()

    def __del__(self):
        self.conn.close()


db = Database()

root = tk.Tk()
root.title("Mosque Management System")

bg_color = "#e6f7ff"
root.configure(bg=bg_color)

tk.Label(root, text="Mosque Management System", font=("Arial", 16, "bold"), fg="darkblue", bg=bg_color).grid(row=0, column=0, columnspan=4, pady=10)

labels = ["ID", "Name", "Type", "Address", "Coordinates", "Imam Name"]
entries = {}

for i, label in enumerate(labels):
    tk.Label(root, text=label, font=("Arial", 12, "bold"), bg=bg_color).grid(row=i+1, column=0, padx=10, pady=5, sticky='e')
    if label == "Type":
        combo = ttk.Combobox(root, values=["مسجد جامع", "مصلى", "زاوية"], state="readonly", font=("Arial", 11))
        combo.grid(row=i+1, column=1, pady=5)
        entries[label] = combo
    else:
        entry = tk.Entry(root, font=("Arial", 11), justify='center')
        entry.grid(row=i+1, column=1, pady=5)
        entries[label] = entry

mosque_list = tk.Listbox(root, width=80, font=("Consolas", 10))
mosque_list.grid(row=1, column=2, rowspan=6, padx=10, pady=5)

def add_entry():
    try:
        db.insert(
            int(entries["ID"].get()),
            entries["Name"].get(),
            entries["Type"].get(),
            entries["Address"].get(),
            entries["Coordinates"].get(),
            entries["Imam Name"].get()
        )
        messagebox.showinfo("Success", "Mosque added successfully.")
        display_all()
    except Exception as e:
        messagebox.showerror("Error", str(e))

def display_all():
    mosque_list.delete(0, tk.END)
    for row in db.display_all():
        mosque_list.insert(tk.END, row)

def search_entry():
    mosque_list.delete(0, tk.END)
    for row in db.search(entries["Name"].get()):
        mosque_list.insert(tk.END, row)

def delete_entry():
    try:
        db.delete(int(entries["ID"].get()))
        messagebox.showinfo("Deleted", "Mosque deleted successfully.")
        display_all()
    except Exception as e:
        messagebox.showerror("Error", str(e))

def update_imam():
    try:
        id_value = int(entries["ID"].get())
        new_imam = entries["Imam Name"].get()
        if not new_imam:
            messagebox.showwarning("Input Required", "Please enter the new Imam Name.")
            return
        db.update_imam(id_value, new_imam)
        messagebox.showinfo("Updated", f"Imam name updated for mosque ID {id_value}.")
        display_all()
    except Exception as e:
        messagebox.showerror("Error", str(e))

def show_on_map():
    try:
        coords = entries["Coordinates"].get()
        name = entries["Name"].get()
        if not coords or "," not in coords:
            messagebox.showwarning("Invalid Input", "Please enter valid coordinates (e.g., 24.71, 46.67).")
            return
        lat, lon = map(float, coords.split(","))
        map_ = folium.Map(location=[lat, lon], zoom_start=15)
        folium.Marker([lat, lon], popup=name).add_to(map_)
        map_.save("mosque_location.html")
        webbrowser.open("mosque_location.html")
    except Exception as e:
        messagebox.showerror("Error", str(e))

def smart_search():
    name_input = entries["Name"].get()
    all_names = db.get_all_names()
    matches = difflib.get_close_matches(name_input, all_names, n=1, cutoff=0.5)
    mosque_list.delete(0, tk.END)
    if matches:
        row = db.get_by_name(matches[0])
        mosque_list.insert(tk.END, row)
    else:
        messagebox.showinfo("No Match", "No close match found.")

btn_style = {"font": ("Arial", 11), "width": 15}

tk.Button(root, text="Add Entry", bg="#d4edda", command=add_entry, **btn_style).grid(row=8, column=0, pady=10)
tk.Button(root, text="Display All", bg="#d1ecf1", command=display_all, **btn_style).grid(row=8, column=1)
tk.Button(root, text="Search", bg="#fff3cd", command=search_entry, **btn_style).grid(row=8, column=2)
tk.Button(root, text="Delete", bg="#f8d7da", command=delete_entry, **btn_style).grid(row=8, column=3)
tk.Button(root, text="Update Imam", bg="#c3f0ca", command=update_imam, **btn_style).grid(row=9, column=0)
tk.Button(root, text="Show on Map", bg="#f0d9ff", command=show_on_map, **btn_style).grid(row=9, column=1)
tk.Button(root, text="Smart Search", bg="#e2eafc", command=smart_search, **btn_style).grid(row=9, column=2)

root.mainloop()
